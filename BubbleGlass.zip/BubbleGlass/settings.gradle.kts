pluginManagement {
  repositories {
    google()
    mavenCentral()
    gradlePluginPortal()
  }
}

dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
  repositories {
    google()
    mavenCentral()
    // Fallback: Meta also publishes the glasses SDK to GitHub Packages, which needs a token.
    // GitHub Actions provides one automatically, so this only kicks in there.
    val ghToken = System.getenv("GITHUB_TOKEN")
    if (!ghToken.isNullOrBlank()) {
      maven {
        url = uri("https://maven.pkg.github.com/facebook/meta-wearables-dat-android")
        credentials {
          username = System.getenv("GITHUB_ACTOR") ?: "github-actions"
          password = ghToken
        }
        content { includeGroup("com.meta.wearable") }
      }
    }
  }
}

rootProject.name = "BubbleGlass"

include(":app")
