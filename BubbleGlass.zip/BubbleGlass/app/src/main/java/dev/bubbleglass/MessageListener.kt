package dev.bubbleglass

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat

/** One incoming text, already pulled out of the notification. */
data class Msg(
    val id: String,
    val sender: String,
    val chat: String?, // group chat name, if it's a group
    val text: String,
    val time: Long,
)

/**
 * Android hands every notification to this service once you grant "notification access".
 * It ignores everything except OpenBubbles (and BlueBubbles, same idea) and forwards new
 * messages to [GlassesBridge].
 */
class MessageListener : NotificationListenerService() {

  companion object {
    private const val TAG = "BubbleGlass"

    val WATCHED_APPS = setOf(
        "com.openbubbles.messaging",
        "com.bluebubbles.messaging",
    )
  }

  override fun onNotificationPosted(sbn: StatusBarNotification) {
    if (sbn.packageName !in WATCHED_APPS) return
    val n = sbn.notification ?: return
    if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return // the "3 new messages" roll-up
    if (sbn.isOngoing) return // OpenBubbles' own "running in background" notification

    val msg = try {
      parse(sbn, n)
    } catch (t: Throwable) {
      Log.w(TAG, "Couldn't read notification", t)
      null
    } ?: return

    GlassesBridge.onMessage(applicationContext, msg, fromTest = false)
  }

  private fun parse(sbn: StatusBarNotification, n: Notification): Msg? {
    // Messaging apps usually use MessagingStyle, which carries the sender and each message.
    val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
    val last = style?.messages?.lastOrNull()
    if (style != null && last != null) {
      val person = last.person
      // No sender, or sender is you = a message you sent. Skip those.
      if (person == null) return null
      val me = style.user.name?.toString()
      val sender = person.name?.toString()?.takeIf { it.isNotBlank() } ?: return null
      if (me != null && sender == me) return null

      val text = last.text?.toString()?.takeIf { it.isNotBlank() } ?: "[Attachment]"
      val chat = style.conversationTitle?.toString()?.takeIf {
        it.isNotBlank() && it != sender
      }
      return Msg(
          id = "${sbn.key}|${last.timestamp}|${text.hashCode()}",
          sender = sender,
          chat = chat,
          text = text,
          time = if (last.timestamp > 0) last.timestamp else sbn.postTime,
      )
    }

    // Fallback: plain notification with a title and text.
    val extras = n.extras ?: return null
    val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
    val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
        ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()
    if (title.isNullOrBlank() || text.isNullOrBlank()) return null
    return Msg(
        id = "${sbn.key}|${text.hashCode()}",
        sender = title,
        chat = null,
        text = text,
        time = sbn.postTime,
    )
  }
}
