package dev.bubbleglass

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/**
 * Runs while BubbleGlass is switched on, so Android doesn't put the app to sleep and the
 * glasses connection can open in the background. Shows a quiet "BubbleGlass is on"
 * notification with a Turn off button.
 */
class GlassesService : Service() {

  companion object {
    const val ACTION_STOP = "dev.bubbleglass.STOP"
    private const val CHANNEL_ID = "running"
    private const val NOTIFICATION_ID = 1
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == ACTION_STOP) {
      GlassesBridge.setOn(this, false)
      stopSelf()
      return START_NOT_STICKY
    }

    val manager = getSystemService(NotificationManager::class.java)
    manager.createNotificationChannel(
        NotificationChannel(CHANNEL_ID, "Running", NotificationManager.IMPORTANCE_LOW)
    )

    val openApp =
        PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE,
        )
    val turnOff =
        PendingIntent.getService(
            this,
            1,
            Intent(this, GlassesService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    val notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("BubbleGlass is on")
            .setContentText("OpenBubbles messages will show on your glasses")
            .setOngoing(true)
            .setContentIntent(openApp)
            .addAction(0, "Turn off", turnOff)
            .build()

    try {
      ServiceCompat.startForeground(
          this,
          NOTIFICATION_ID,
          notification,
          ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE,
      )
    } catch (t: Throwable) {
      GlassesBridge.report("Couldn't keep running in the background: ${t.message}")
      stopSelf()
      return START_NOT_STICKY
    }

    if (!GlassesBridge.isOn(this)) {
      stopSelf()
      return START_NOT_STICKY
    }
    GlassesBridge.ensureInitialized(this)
    return START_STICKY
  }

  override fun onDestroy() {
    GlassesBridge.close()
    super.onDestroy()
  }
}
