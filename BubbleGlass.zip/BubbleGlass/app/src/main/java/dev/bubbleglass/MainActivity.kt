package dev.bubbleglass

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.meta.wearable.dat.core.Wearables
import com.meta.wearable.dat.core.types.RegistrationState
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** The phone screen: a short setup checklist plus on/off and test buttons. */
class MainActivity : Activity() {

  private companion object {
    const val REQ_PERMISSIONS = 1
  }

  private val uiScope = MainScope()

  private lateinit var notifStatus: TextView
  private lateinit var btStatus: TextView
  private lateinit var metaStatus: TextView
  private lateinit var onSwitch: Switch
  private lateinit var popupSwitch: Switch
  private lateinit var glassesStatus: TextView
  private lateinit var lastMessage: TextView
  private lateinit var lastError: TextView

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(buildUi())
    uiScope.launch { GlassesBridge.status.collect { showStatus(it) } }
  }

  override fun onResume() {
    super.onResume()
    GlassesBridge.ensureInitialized(this)
    refreshChecklist()
  }

  override fun onDestroy() {
    uiScope.cancel()
    super.onDestroy()
  }

  // ---------------------------------------------------------------- checklist

  private fun hasNotificationAccess() =
      NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

  private fun hasBluetooth() =
      ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
          PackageManager.PERMISSION_GRANTED

  private fun refreshChecklist() {
    notifStatus.text = if (hasNotificationAccess()) "✅ Allowed" else "❌ Not allowed yet"
    btStatus.text = if (hasBluetooth()) "✅ Allowed" else "❌ Not allowed yet"
    onSwitch.isChecked = GlassesBridge.isOn(this)
    popupSwitch.isChecked = GlassesBridge.isPopup(this)
    showStatus(GlassesBridge.status.value)
  }

  private fun showStatus(s: GlassesBridge.Status) {
    metaStatus.text =
        when {
          !hasBluetooth() -> "Allow Bluetooth first"
          s.registration == RegistrationState.REGISTERED ->
              if (s.devicesFound > 0) "✅ Connected" else "✅ Connected (no glasses seen yet)"
          s.registration == RegistrationState.REGISTERING -> "Connecting..."
          else -> "❌ Not connected yet"
        }
    glassesStatus.text = "Glasses: ${s.glasses}"
    lastMessage.text = "Last message: ${s.lastMessage ?: "none yet"}"
    lastError.text = s.lastError?.let { "Last problem (tap to clear): $it" } ?: ""
    lastError.visibility = if (s.lastError == null) View.GONE else View.VISIBLE
  }

  // ---------------------------------------------------------------- actions

  private fun openNotificationAccess() {
    val component = ComponentName(this, MessageListener::class.java).flattenToString()
    val detail =
        Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
            .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, component)
    try {
      startActivity(detail)
    } catch (e: Exception) {
      startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }
  }

  private fun openAppInfo() {
    startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
    )
  }

  private fun askPermissions() {
    val wanted = mutableListOf(Manifest.permission.BLUETOOTH_CONNECT)
    if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
    requestPermissions(wanted.toTypedArray(), REQ_PERMISSIONS)
  }

  override fun onRequestPermissionsResult(
      requestCode: Int,
      permissions: Array<out String>,
      grantResults: IntArray,
  ) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    GlassesBridge.ensureInitialized(this)
    refreshChecklist()
  }

  private fun connectToMeta() {
    if (!hasBluetooth()) {
      toast("Allow Bluetooth first (step 2)")
      return
    }
    if (!GlassesBridge.ensureInitialized(this)) return
    if (Wearables.registrationState.value == RegistrationState.REGISTERED) {
      toast("Already connected")
      return
    }
    // Opens the Meta AI app to approve BubbleGlass, then comes back here.
    Wearables.startRegistration(this)
  }

  private fun setOn(on: Boolean) {
    if (on && (!hasBluetooth() || !hasNotificationAccess())) {
      toast("Finish steps 1 and 2 first")
      onSwitch.isChecked = false
      return
    }
    GlassesBridge.setOn(this, on)
    val intent = Intent(this, GlassesService::class.java)
    if (on) ContextCompat.startForegroundService(this, intent) else stopService(intent)
  }

  private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

  // ---------------------------------------------------------------- layout (built in code)

  private fun buildUi(): View {
    val pad = dp(20)
    val column =
        LinearLayout(this).apply {
          orientation = LinearLayout.VERTICAL
          setPadding(pad, pad, pad, pad)
        }

    column.addView(heading("BubbleGlass", 26f))
    column.addView(body("Shows your OpenBubbles messages on Meta Ray-Ban Display."))

    column.addView(heading("1. Notification access", 18f))
    notifStatus = body("")
    column.addView(notifStatus)
    column.addView(button("Open notification access") { openNotificationAccess() })
    column.addView(
        small(
            "If the BubbleGlass toggle is greyed out: tap App info below, then the ⋮ menu " +
                "(top right), then \"Allow restricted settings\". Come back and try again."
        )
    )
    column.addView(button("App info") { openAppInfo() })

    column.addView(heading("2. Bluetooth", 18f))
    btStatus = body("")
    column.addView(btStatus)
    column.addView(button("Allow Bluetooth") { askPermissions() })

    column.addView(heading("3. Connect to Meta AI", 18f))
    metaStatus = body("")
    column.addView(metaStatus)
    column.addView(button("Connect") { connectToMeta() })
    column.addView(
        small(
            "Needs Developer Mode in the Meta AI app: Settings > App info > tap the app " +
                "version 5 times > turn on Developer Mode."
        )
    )

    column.addView(heading("4. Go", 18f))
    onSwitch =
        Switch(this).apply {
          text = "BubbleGlass on"
          textSize = 16f
          setOnClickListener { setOn(isChecked) }
        }
    column.addView(onSwitch)
    popupSwitch =
        Switch(this).apply {
          text = "Pop up each new message (off = only when I open the feed)"
          textSize = 16f
          setOnClickListener { GlassesBridge.setPopup(this@MainActivity, isChecked) }
        }
    column.addView(popupSwitch)
    column.addView(button("Send test message") { GlassesBridge.sendTest(this) })
    column.addView(button("Open feed on glasses") { GlassesBridge.openFeed(this) })
    column.addView(button("Close on glasses") { GlassesBridge.close() })

    column.addView(heading("Status", 18f))
    glassesStatus = body("")
    lastMessage = body("")
    lastError =
        body("").apply {
          setTextColor(0xFFD32F2F.toInt())
          setOnClickListener { GlassesBridge.clearError() }
        }
    column.addView(glassesStatus)
    column.addView(lastMessage)
    column.addView(lastError)

    return ScrollView(this).apply {
      fitsSystemWindows = true
      addView(column)
    }
  }

  private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

  private fun heading(text: String, size: Float) =
      TextView(this).apply {
        this.text = text
        textSize = size
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(18), 0, dp(4))
      }

  private fun body(text: String) =
      TextView(this).apply {
        this.text = text
        textSize = 15f
        setPadding(0, dp(2), 0, dp(2))
      }

  private fun small(text: String) =
      TextView(this).apply {
        this.text = text
        textSize = 13f
        alpha = 0.7f
        setPadding(0, dp(4), 0, dp(4))
      }

  private fun button(label: String, onClick: () -> Unit) =
      Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
      }
}
