package dev.bubbleglass

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.text.format.DateFormat
import android.util.Log
import androidx.core.content.ContextCompat
import com.meta.wearable.dat.core.Wearables
import com.meta.wearable.dat.core.selectors.AutoDeviceSelector
import com.meta.wearable.dat.core.session.DeviceSession
import com.meta.wearable.dat.core.session.DeviceSessionState
import com.meta.wearable.dat.core.types.RegistrationState
import com.meta.wearable.dat.display.Display
import com.meta.wearable.dat.display.addDisplay
import com.meta.wearable.dat.display.removeDisplay
import com.meta.wearable.dat.display.types.DisplayState
import com.meta.wearable.dat.display.views.ContentScope
import com.meta.wearable.dat.display.views.Direction
import com.meta.wearable.dat.display.views.FlexBoxBackground
import com.meta.wearable.dat.display.views.FlexBoxScope
import com.meta.wearable.dat.display.views.TextColor
import com.meta.wearable.dat.display.views.TextStyle
import java.util.Date
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Everything that talks to the glasses lives here.
 *
 * Pop-up mode (default): a new message opens BubbleGlass on the glasses, shows the message,
 * and closes again after [POPUP_MS]. Tap the card on the glasses to dismiss it early.
 *
 * Feed mode (pop-up off): nothing opens by itself. Tap "Open feed on glasses" in the phone app
 * and it stays open, updating as messages arrive, until you do the two-finger back tap.
 *
 * All state is touched on the main thread only.
 */
object GlassesBridge {

  private const val TAG = "BubbleGlass"
  private const val POPUP_MS = 15_000L // how long a pop-up stays up after the last message
  private const val OPEN_TIMEOUT_MS = 20_000L // give up if the glasses don't answer by then
  private const val MAX_SHOWN = 3 // newest messages kept on screen
  private const val PREFS = "bubbleglass"

  data class Status(
      val sdkReady: Boolean = false,
      val registration: RegistrationState = RegistrationState.UNAVAILABLE,
      val devicesFound: Int = 0,
      val glasses: String = "Closed",
      val lastMessage: String? = null,
      val lastError: String? = null,
  )

  private val _status = MutableStateFlow(Status())
  val status: StateFlow<Status> = _status.asStateFlow()

  private val scope =
      CoroutineScope(
          SupervisorJob() +
              Dispatchers.Main.immediate +
              CoroutineExceptionHandler { _, t ->
                Log.e(TAG, "Unexpected error", t)
                report(t.message ?: t.javaClass.simpleName)
              }
      )

  private lateinit var appContext: Context
  private var sdkInitialized = false

  private var session: DeviceSession? = null
  private var display: Display? = null
  private var displayReady = false
  private var keepOpen = false // true when the feed was opened by hand

  private val sessionJobs = mutableListOf<Job>()
  private var openingJob: Job? = null
  private var displayJob: Job? = null
  private var openTimeoutJob: Job? = null
  private var autoCloseJob: Job? = null

  private val recent = mutableListOf<Msg>() // newest first
  private val seen = LinkedHashSet<String>() // so a re-posted notification doesn't pop up twice

  // ---------------------------------------------------------------- settings

  private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  fun isOn(ctx: Context) = prefs(ctx).getBoolean("on", false)

  fun setOn(ctx: Context, on: Boolean) {
    prefs(ctx).edit().putBoolean("on", on).apply()
    if (!on) close()
  }

  fun isPopup(ctx: Context) = prefs(ctx).getBoolean("popup", true)

  fun setPopup(ctx: Context, popup: Boolean) = prefs(ctx).edit().putBoolean("popup", popup).apply()

  // ---------------------------------------------------------------- setup

  /** Starts the Meta SDK once Bluetooth permission is granted. Safe to call repeatedly. */
  fun ensureInitialized(ctx: Context): Boolean {
    appContext = ctx.applicationContext
    if (sdkInitialized) return true
    val granted =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
    if (!granted) return false

    var ok = true
    Wearables.initialize(appContext).onFailure { error, _ ->
      ok = false
      report("Glasses SDK didn't start: ${error.description}")
    }
    if (!ok) return false
    sdkInitialized = true

    scope.launch {
      Wearables.registrationState.collect { state ->
        _status.update { it.copy(sdkReady = true, registration = state) }
      }
    }
    scope.launch {
      Wearables.devices.collect { ids -> _status.update { it.copy(devicesFound = ids.size) } }
    }
    scope.launch {
      Wearables.registrationErrorStream.collect { error ->
        report(error.getLocalizedDescription(appContext))
      }
    }
    return true
  }

  // ---------------------------------------------------------------- incoming messages

  fun onMessage(ctx: Context, msg: Msg, fromTest: Boolean) {
    appContext = ctx.applicationContext
    if (!fromTest && !isOn(appContext)) return
    if (!seen.add(msg.id)) return
    if (seen.size > 200) seen.iterator().let { it.next(); it.remove() }

    recent.add(0, msg)
    while (recent.size > MAX_SHOWN) recent.removeAt(recent.size - 1)
    _status.update { it.copy(lastMessage = "${msg.sender}: ${msg.text.take(80)}") }

    when {
      session != null -> render() // already open (or opening; it renders once ready)
      fromTest || isPopup(appContext) -> openOnGlasses()
      else -> Unit // feed mode: it'll be there next time you open the feed
    }
  }

  fun sendTest(ctx: Context) {
    val now = System.currentTimeMillis()
    onMessage(
        ctx,
        Msg(
            id = "test-$now",
            sender = "BubbleGlass",
            chat = null,
            text = "Test message. If you can read this, it's working.",
            time = now,
        ),
        fromTest = true,
    )
  }

  /** Opens the feed on the glasses and keeps it open. */
  fun openFeed(ctx: Context) {
    appContext = ctx.applicationContext
    keepOpen = true
    autoCloseJob?.cancel()
    if (session != null) render() else openOnGlasses()
  }

  /** Closes BubbleGlass on the glasses (the glasses go back to normal). */
  fun close() {
    keepOpen = false
    cleanup(stopSession = true)
  }

  // ---------------------------------------------------------------- glasses session

  private fun openOnGlasses() {
    if (session != null || openingJob?.isActive == true) return
    if (!ensureInitialized(appContext)) {
      report("Allow Bluetooth in BubbleGlass first.")
      return
    }

    setGlasses("Opening...")
    openingJob =
        scope.launch {
          // Right after the app wakes up, the SDK can take a moment to report "registered".
          val registered =
              withTimeoutOrNull(5_000L) {
                Wearables.registrationState.first { it == RegistrationState.REGISTERED }
              } != null
          if (!registered) {
            setGlasses("Closed")
            report("Not connected to Meta AI yet. Open BubbleGlass and tap Connect.")
            return@launch
          }
          if (session == null) startSession()
        }
  }

  private fun startSession() {
    Wearables.createSession(AutoDeviceSelector(filter = { it.isDisplayCapable() }))
        .fold(
            onSuccess = { s ->
              session = s
              sessionJobs += scope.launch { s.state.collect { state -> onSessionState(s, state) } }
              sessionJobs +=
                  scope.launch {
                    s.errors.collect { error ->
                      if (session === s) {
                        report(error.description)
                        close()
                      }
                    }
                  }
              openTimeoutJob?.cancel()
              openTimeoutJob =
                  scope.launch {
                    delay(OPEN_TIMEOUT_MS)
                    if (session === s && !displayReady) {
                      report("Glasses didn't respond. Are they on and connected to Meta AI?")
                      close()
                    }
                  }
              s.start()
            },
            onFailure = { error, _ ->
              setGlasses("Closed")
              report(error.description)
            },
        )
  }

  private fun onSessionState(s: DeviceSession, state: DeviceSessionState) {
    if (session !== s) return
    Log.i(TAG, "Session state: $state")
    when (state) {
      DeviceSessionState.STARTED -> if (display == null) attachDisplay(s)
      DeviceSessionState.PAUSED -> setGlasses("Paused (something else took over the display)")
      DeviceSessionState.STOPPED -> {
        keepOpen = false
        cleanup(stopSession = false)
      }
      else -> Unit
    }
  }

  private fun attachDisplay(s: DeviceSession) {
    s.addDisplay()
        .fold(
            onSuccess = { d ->
              display = d
              displayJob?.cancel()
              displayJob =
                  scope.launch {
                    var started = false
                    d.state.collect { state ->
                      if (session !== s) return@collect
                      Log.i(TAG, "Display state: $state")
                      displayReady = state == DisplayState.STARTED
                      if (displayReady) {
                        started = true
                        openTimeoutJob?.cancel()
                        setGlasses(if (keepOpen) "Feed open" else "Showing message")
                        render()
                      } else if (state == DisplayState.STOPPED && started) {
                        close() // e.g. the two-finger back tap on the glasses
                      }
                    }
                  }
            },
            onFailure = { error, _ ->
              report(error.description)
              close()
            },
        )
  }

  private fun cleanup(stopSession: Boolean) {
    openingJob?.cancel()
    openingJob = null
    autoCloseJob?.cancel()
    autoCloseJob = null
    openTimeoutJob?.cancel()
    openTimeoutJob = null
    displayJob?.cancel()
    displayJob = null

    val s = session
    session = null
    display = null
    displayReady = false
    sessionJobs.forEach { it.cancel() }
    sessionJobs.clear()

    if (stopSession && s != null) {
      s.removeDisplay()
      s.stop()
    }
    setGlasses("Closed")
  }

  // ---------------------------------------------------------------- what's drawn on the lens

  private fun render() {
    val d = display ?: return
    if (!displayReady) return
    val items = recent.toList()
    val popup = !keepOpen
    if (popup) {
      autoCloseJob?.cancel()
      autoCloseJob =
          scope.launch {
            delay(POPUP_MS)
            if (!keepOpen) close()
          }
    }
    scope.launch(Dispatchers.IO) {
      d.sendContent { messageScreen(items, popup) }
          .fold(
              onSuccess = {},
              onFailure = { error, _ -> report("Couldn't draw on glasses: ${error.description}") },
          )
    }
  }

  private fun ContentScope.messageScreen(items: List<Msg>, popup: Boolean) {
    flexBox(direction = Direction.COLUMN, gap = 10) {
      if (items.isEmpty()) {
        flexBox(padding = 24, background = FlexBoxBackground.CARD) {
          text("No new messages", style = TextStyle.HEADING)
          text(
              "New OpenBubbles texts will show up here.",
              style = TextStyle.BODY,
              color = TextColor.SECONDARY,
          )
        }
      } else {
        items.forEachIndexed { i, m -> messageCard(m, newest = i == 0, popup = popup) }
      }
    }
  }

  private fun FlexBoxScope.messageCard(m: Msg, newest: Boolean, popup: Boolean) {
    flexBox(
        gap = 6,
        padding = 24,
        background = FlexBoxBackground.CARD,
        // Tapping a pop-up dismisses it. In feed mode taps do nothing.
        onClick = { scope.launch { if (popup && !keepOpen) close() } },
    ) {
      if (m.chat != null) {
        text(m.chat, style = TextStyle.META, color = TextColor.SECONDARY)
      }
      text(m.sender, style = if (newest) TextStyle.HEADING else TextStyle.BODY)
      if (newest) {
        text(m.text.take(400), style = TextStyle.BODY)
      } else {
        text(m.text.take(140), style = TextStyle.BODY, color = TextColor.SECONDARY)
      }
      text(timeLabel(m.time), style = TextStyle.META, color = TextColor.SECONDARY)
    }
  }

  private fun timeLabel(time: Long): String = DateFormat.getTimeFormat(appContext).format(Date(time))

  // ---------------------------------------------------------------- status for the phone screen

  private fun setGlasses(text: String) = _status.update { it.copy(glasses = text) }

  fun report(problem: String) {
    Log.w(TAG, problem)
    _status.update { it.copy(lastError = problem) }
  }

  fun clearError() = _status.update { it.copy(lastError = null) }
}
