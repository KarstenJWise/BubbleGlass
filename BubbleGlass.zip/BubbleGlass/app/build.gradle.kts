import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
}

android {
  namespace = "dev.bubbleglass"
  compileSdk = 36

  defaultConfig {
    applicationId = "dev.bubbleglass"
    minSdk = 31
    targetSdk = 34
    versionCode = 1
    versionName = "1.0"

    // Developer Mode on the glasses doesn't need real Meta credentials, so these stay 0.
    manifestPlaceholders["mwdat_application_id"] = "0"
    manifestPlaceholders["mwdat_client_token"] = "0"
  }

  // One fixed signing key so a newer build installs over the old one without uninstalling.
  signingConfigs {
    create("personal") {
      storeFile = file("bubbleglass.keystore")
      storePassword = "bubbleglass"
      keyAlias = "bubbleglass"
      keyPassword = "bubbleglass"
    }
  }

  buildTypes {
    release {
      isMinifyEnabled = false
      signingConfig = signingConfigs.getByName("personal")
    }
    debug {
      signingConfig = signingConfigs.getByName("personal")
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }

  packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }

  // Personal sideloaded app: don't let style warnings block the build.
  lint {
    checkReleaseBuilds = false
    abortOnError = false
  }
}

kotlin { compilerOptions { jvmTarget = JvmTarget.JVM_17 } }

dependencies {
  implementation("com.meta.wearable:mwdat-core:0.9.0")
  implementation("com.meta.wearable:mwdat-display:0.9.0")
  implementation("androidx.core:core-ktx:1.16.0")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
}
