# BubbleGlass

Shows your OpenBubbles (iMessage) notifications on Meta Ray-Ban Display glasses. It only reads messages. You can't reply from it.

## How it works

- Android passes OpenBubbles notifications to BubbleGlass. Notifications from every other app are ignored.
- **Pop-up mode (default):** when a new message arrives, BubbleGlass opens on the glasses, shows the sender and text, and closes after about 15 seconds. Tap the card to close it sooner.
- **Feed mode:** turn off "Pop up each new message". Nothing opens by itself. Tap "Open feed on glasses" and it stays open with your latest 3 messages until you two-finger tap the temple.
- When BubbleGlass is on the glasses, it takes over the whole display. If you're using navigation or something else, a pop-up interrupts it.

## Get the app on your phone (no computer software needed)

1. Make a free account at github.com and create a **new repository** (Public is easiest).
2. In the repo, choose **Add file → Upload files** and upload `BubbleGlass.zip` as-is. Don't unzip it.
3. Choose **Add file → Create new file**. For the name, type `.github/workflows/build.yml` (the slashes create the folders). Paste in the contents of `build.yml`, then commit.
4. Open the **Actions** tab and wait about 5 minutes for the build to show a green check.
5. On your phone, open the repo's **Releases** section and tap **BubbleGlass.apk**.
6. Open the downloaded file. Android will ask you to allow installs from your browser: tap **Settings → Allow from this source**, go back, and tap **Install**. If Play Protect warns you, choose **Install anyway**. It warns about anything that didn't come from the Play Store.

To update later, upload a new `BubbleGlass.zip` to the same repo. A new release shows up, and it installs over the old version.

## One-time setup in the app

1. **Notification access:** tap "Open notification access" and switch on BubbleGlass.
   - If the switch is greyed out, Android 13 and later block this setting for sideloaded apps. Go to **App info → ⋮ (top right) → Allow restricted settings**, then try again.
2. **Bluetooth:** tap "Allow Bluetooth".
3. **Meta AI:** first turn on Developer Mode in the Meta AI app (**Settings → App info → tap the app version 5 times → Developer Mode on**). Then tap **Connect** in BubbleGlass and approve it in Meta AI.
   - Display apps need Meta AI app v272+ and glasses firmware v125+.
4. Switch **BubbleGlass on**, then tap **Send test message**.

## If something's off

- The last error shows in red at the bottom of the app.
- Getting the same message twice, or not seeing group messages? OpenBubbles might format its notifications differently than expected. The code that reads them is `MessageListener.kt`.
- Pop-ups never appear, but "Open feed on glasses" works: your glasses may not allow apps to open in the background. Use feed mode instead.
